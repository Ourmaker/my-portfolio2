/**
 * Legacy Index page - redirects to Home
 * Kept for backward compatibility
 */
import Home from './Home';

const Index = () => {
  return <Home />;
};

export default Index;
